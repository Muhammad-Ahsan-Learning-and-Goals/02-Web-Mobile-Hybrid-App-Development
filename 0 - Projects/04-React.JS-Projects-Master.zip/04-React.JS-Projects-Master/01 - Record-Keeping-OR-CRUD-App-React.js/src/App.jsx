import React from 'react'
import Record_Keeping from "./Record_Keeping";

const App = () => {
  return <div>
    
    <Record_Keeping/>
    
    </div>;
}

export default App