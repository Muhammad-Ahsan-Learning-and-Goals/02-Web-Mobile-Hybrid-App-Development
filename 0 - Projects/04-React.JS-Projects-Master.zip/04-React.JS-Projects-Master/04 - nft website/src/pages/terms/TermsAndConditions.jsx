import React from "react";

const TermsAndConditions = () => {
  return (
    <>
      <div className="container-fliud  me-3 ms-3">
        <h1 className="white_color text-center"> Terms and Conditions </h1>
        <p className="white_color">
          Lorem ipsum dolor, sit amet consectetur adipisicing elit. Amet
          nesciunt unde magni? Dolores accusantium quis id eligendi nesciunt
          similique! Repellat alias laboriosam commodi id fugit non eum, animi
          delectus dicta!
        </p>

        <h2 className="white_color">Terms and Conditions </h2>
        <p className="white_color">
          Lorem ipsum dolor sit amet consectetur adipisicing elit. Magni eveniet
          alias id, tempora officiis commodi consectetur. Nobis unde harum
          deserunt nulla, nesciunt, veniam voluptatem tenetur necessitatibus
          doloremque quibusdam, veritatis cumque.
        </p>

        <h2 className="white_color">Terms and Conditions </h2>
        <p className="white_color">
          Lorem ipsum dolor sit amet consectetur adipisicing elit. Magni eveniet
          alias id, tempora officiis commodi consectetur. Nobis unde harum
          deserunt nulla, nesciunt, veniam voluptatem tenetur necessitatibus
          doloremque quibusdam, veritatis cumque.
        </p>

        <h2 className="white_color">Terms and Conditions </h2>
        <p className="white_color">
          Lorem ipsum dolor sit amet consectetur adipisicing elit. Magni eveniet
          alias id, tempora officiis commodi consectetur. Nobis unde harum
          deserunt nulla, nesciunt, veniam voluptatem tenetur necessitatibus
          doloremque quibusdam, veritatis cumque.
        </p>

        <h2 className="white_color">Terms and Conditions </h2>
        <p className="white_color">
          Lorem ipsum dolor sit amet consectetur adipisicing elit. Magni eveniet
          alias id, tempora officiis commodi consectetur. Nobis unde harum
          deserunt nulla, nesciunt, veniam voluptatem tenetur necessitatibus
          doloremque quibusdam, veritatis cumque.
        </p>

        <h2 className="white_color">Terms and Conditions </h2>
        <p className="white_color">
          Lorem ipsum dolor sit amet consectetur adipisicing elit. Magni eveniet
          alias id, tempora officiis commodi consectetur. Nobis unde harum
          deserunt nulla, nesciunt, veniam voluptatem tenetur necessitatibus
          doloremque quibusdam, veritatis cumque.
        </p>

        <h2 className="white_color">Terms and Conditions </h2>
        <p className="white_color">
          Lorem ipsum dolor sit amet consectetur adipisicing elit. Magni eveniet
          alias id, tempora officiis commodi consectetur. Nobis unde harum
          deserunt nulla, nesciunt, veniam voluptatem tenetur necessitatibus
          doloremque quibusdam, veritatis cumque.
        </p>
      </div>
    </>
  );
};

export default TermsAndConditions;
